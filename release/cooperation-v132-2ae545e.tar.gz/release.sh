#!/bin/bash
set -Eeuo pipefail
umask 077
archive=${1:?Supply release archive}
root=/opt/cuihang-live
db="$root/data/command-center.sqlite"
landing=/www/wwwroot/room-booking-upgrade-20261013/public/index.html
service=cuihang-live.service
base=https://43.135.1.109/live
backup=$(mktemp -d /www/backup/cooperation-v132-XXXXXXXX)
stage="$backup/stage"
mkdir "$stage" "$backup/original"
printf 'BACKUP_DIR=%s\n' "$backup"
tar -xzf "$archive" -C "$stage" --no-same-owner --no-same-permissions
cd "$stage"
sha256sum --quiet --check manifest.sha256
mapfile -t files < install-files.txt
test "${#files[@]}" -eq 15
test "$(systemctl show "$service" -p WorkingDirectory --value)" = "$root"
systemctl is-active --quiet "$service"
pid=$(systemctl show "$service" -p MainPID --value)
if tr '\0' '\n' < "/proc/$pid/environ" | awk '/^ASSISTANT_ACCESS=(pilot|employees)$/{found=1} END{exit !found}'; then
  echo AI_OVERRIDE_PRESENT >&2
  exit 1
fi
if [[ -f $root/.env ]]; then
  if grep -Eq '^[[:space:]]*(export[[:space:]]+)?ASSISTANT_ACCESS[[:space:]]*=' "$root/.env"; then
    grep -Eq '^ASSISTANT_ACCESS=off[[:space:]]*$' "$root/.env"
  fi
fi
get() { curl -fsS --max-time 8 --retry 4 --retry-connrefused --retry-delay 1 "$1"; }
code() { curl -sS --max-time 8 -o /dev/null -w '%{http_code}' "$1"; }
get "$base/" > "$backup/before"
grep -Fq '版本 v1.3.1' "$backup/before"
get http://127.0.0.1:3000/ > "$backup/before-landing"
cmp "$backup/before-landing" "$landing"
grep -Fq '版本 v1.3.1' "$backup/before-landing"
sed 's/版本 v1\.3\.1/版本 v1.3.2/' "$backup/before-landing" > landing.html
test "$(get "$base/api/health")" = '{"ok":true}'
test "$(code "$base/api/ai/status")" = 404
sqlite3 -readonly -cmd '.timeout 5000' "$db" ".backup $backup/command-center.sqlite"
test "$(sqlite3 -readonly "$backup/command-center.sqlite" 'PRAGMA quick_check;')" = ok
test "$(sqlite3 -readonly "$backup/command-center.sqlite" "SELECT value FROM metadata WHERE key='demo';")" = 0
echo LIVE_BACKUP_OK

files+=(landing.html)
destination() { if [[ $1 == landing.html ]]; then printf '%s' "$landing"; else printf '%s/%s' "$root" "$1"; fi; }
replace() {
  local source=$1 dest=$2 tmp
  tmp=$(mktemp "${dest}.release-XXXXXXXX") || return
  if [[ -f $dest ]]; then
    chmod --reference="$dest" -- "$tmp" || return
    chown --reference="$dest" -- "$tmp" || return
  else
    chmod 0644 "$tmp" || return
  fi
  cat -- "$source" > "$tmp" || return
  mv -fT -- "$tmp" "$dest"
}
for file in "${files[@]}"; do
  [[ $file =~ ^(server\.mjs|package\.json|landing\.html|(public|lib)/[a-zA-Z0-9_./-]+)$ && $file != *..* ]]
  target=$(destination "$file")
  test -s "$file"
  test ! -L "$target"
  test -d "$(dirname "$target")"
  case "$file" in *.js|*.mjs) node --input-type=module --check < "$file" ;; esac
  if [[ -f $target ]]; then
    mkdir -p "$backup/original/$(dirname "$file")"
    cp -a -- "$target" "$backup/original/$file"
  fi
done

applied=()
rollback() {
  local result=$? failed=0 file target
  trap - ERR
  set +e
  for file in "${applied[@]}"; do
    target=$(destination "$file")
    if [[ -f "$backup/original/$file" ]]; then
      replace "$backup/original/$file" "$target" || failed=1
    else
      rm -f -- "$target" || failed=1
    fi
  done
  systemctl restart "$service" || failed=1
  printf 'COOPERATION_V132_ROLLBACK backup=%s failed=%s\n' "$backup" "$failed" >&2
  exit "$result"
}
trap rollback ERR
for file in "${files[@]}"; do
  target=$(destination "$file")
  applied+=("$file")
  replace "$file" "$target"
done
systemctl restart "$service"
test "$(get "$base/api/health")" = '{"ok":true}'
get "$base/" > "$backup/verified-home"
cmp "$backup/verified-home" public/index.html
get http://127.0.0.1:3000/ > "$backup/verified-landing"
cmp "$backup/verified-landing" landing.html
get "$base/entry" | awk '/20261128-slot-identity/{seen=1} END{exit !seen}'
curl -fsSI --max-time 8 "$base/entry.js?v=20261128-slot-identity" | awk 'tolower($0) ~ /^cache-control:.*immutable/{seen=1} END{exit !seen}'
get "$base/api/entry/bootstrap?completeness=1&date=$(TZ=Asia/Shanghai date +%F)" | node -e '
  const x=JSON.parse(require("node:fs").readFileSync(0,"utf8"));
  if(!x.accounts?.length||!Number.isFinite(x.completeness?.summary?.expected)||!x.month?.days?.length)process.exit(1)
'
get "$base/tearoom/" | awk '/荣誉墙/{honor=1} /href="\.\/assistant\.html"/{ai=1} END{exit !(honor&&!ai)}'
test "$(code "$base/api/dashboard/feedback")" = 401
test "$(code "$base/api/ai/status")" = 404
test "$(code "$base/tearoom/assistant.html")" = 404
test "$(get "$base/booking-app/api/health")" = '{"ok":true}'
systemctl is-active --quiet "$service"
trap - ERR
printf 'COOPERATION_V132_RELEASE_OK source=2ae545e backup=%s\n' "$backup"
