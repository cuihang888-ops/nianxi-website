window.lucide?.createIcons();
